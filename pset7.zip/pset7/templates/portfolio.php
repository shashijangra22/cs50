<p>
    Welcome back, <strong><?=$username?>!</strong> Your current deposit is <strong>$<?=number_format($cash, 2)?></strong>
</p>
<table class="table table-hover">
    <thead>
        <tr>
            <th>Symbol</th>
            <th>Name</th>
            <th>Shares</th>
            <th>Price Bought</th>
            <th>Price Current</th>
            <th>Total Bought</th>
            <th>Total Current</th>
            <th>Total gains / losses</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($shares as $share): ?>
            <tr>
                <td><?= $share["symbol"] ?></td>
                <td><?= $share["name"] ?></td>
                <td><?= $share["shares"] ?></td>
                <td><?= number_format($share["price_bought"], 2) ?></td>
                <td><?= number_format($share["price_cur"], 2) ?></td>
                <td><?= number_format($share["total_bought"], 2) ?></td>
                <td><?= number_format($share["total_cur"], 2) ?></td>
                <td><?= number_format($share["profit"], 2) ?></td>
            </tr>
        <? endforeach ?>
    </tbody>
</table>
