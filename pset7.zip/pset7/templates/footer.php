            </div>

            <hr>
            <br/><br/><br/><br/>
            <hr>
            <hr>

            <ul class="menu">
                <a href="index.php">  Portfolio  </a>-
                <a href="quote.php">  Quote  </a>-
                <a href="buy.php">  Buy  </a>-
                <a href="sell.php">  Sell  </a>-
                <a href="history.php">  History  </a>-
                <a href="changepw.php">  Change Password  </a>-
                <a href="logout.php"><strong>  Log Out</strong></a>-
            </ul>

            <div id="bottom">
                Copyright &#169; <a href="http://www.xicoofficial.co">XicoOfficial</a>
            </div>

        </div>

    </body>

</html>
