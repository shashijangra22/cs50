/**
 * recover.c
 *
 * Computer Science 50
 * Problem Set 4
 *
 * Recovers JPEGs from a forensic image.
 */
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdint.h>
#include<cs50.h>
typedef uint8_t BYTE;   // making an alias as BYTE
BYTE jpeg1[4]={0xff,0xd8,0xff,0xe0};
BYTE jpeg2[4]={0xff,0xd8,0xff,0xe1};
bool isJPEG(BYTE temp[]) // a function which checks whether given block is a starting of a JPEG or not by checking its starting 4 bits
{
    if(memcmp(jpeg1,temp,4)==0 || memcmp(jpeg2,temp,4)==0)
        return true;
    return false;
}
int main(int argc, char* argv[])
{
    FILE* inptr=fopen("card.raw","r");  // opening input file
    if(inptr==NULL)     // ensuring it opens successfully
    {
        fclose(inptr);
        printf("Input File not found!");
        return 1;
    }
    BYTE buffer[512]={0};   // buffer to store each block
    int count=0,flag=0;    // an image counter & a flag to keep track when JPEGs starts in raw file
    FILE* img;      // output image file pointer
    fread(buffer,512,1,inptr);  // reading 512 bytes from raw file
    while(fread(buffer,512,1,inptr)>0)   // reading 512 Bytes of the input file until EOF 
    {
        BYTE temp[4]={buffer[0],buffer[1],buffer[2],buffer[3]}; // copying starting bits of each block to temp
        if(isJPEG(temp))      // if a new JPEG is found
        {
            char title[8]; // allocating memory to an array which stores image name
            sprintf(title,"%03d.jpg",count); // creating a file instance in directory
            if(flag==0)     // handles starting JPEG
            {
                img=fopen(title,"w");   // opening the first JPEG with name title
                fwrite(buffer,sizeof(buffer),1,img);    // writing first block to the first JPEG
                flag=1; // turning flag on to say that first JPEG is encountered 
            }
            if(flag==1)     // handles all consecutive JPEGs after the first JPEG
            {
                count++;    // incrementing JPEGs counter
                fclose(img);    // closing any opened JPEG
                img=fopen(title,"w");   //  opens a new jpeg with a name title
                fwrite(buffer,sizeof(buffer),1,img);    // writes 512 bytes to the created jpg
            }
        }
        else if(flag==1)    // writing to the same JPEG block by block until new JPEG not found
            fwrite(buffer,sizeof(buffer),1,img);
    }
    fclose(img);
    fclose(inptr);
    return 0;
}
