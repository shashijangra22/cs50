/**
 * helpers.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Helper functions for Problem Set 3.
 */
       
#include <cs50.h>

#include "helpers.h"

bool mysearch(int value, int values[], int start,int end)
{
	if(end>=start)
	{
		int mid=(start+end)/2;
		if(values[mid]==value)
			return true;
		else if(values[mid]>value)
			return mysearch(value,values,start,mid-1);
		else
			return mysearch(value,values,mid+1,end); 
	}
	return false;
}
/**
 * Returns true if value is in array of n values, else false.
 */
bool search(int value, int values[], int n)
{
    if(mysearch(value,values,0,n-1))
        return true;
    return false;
}

/**
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
	int swapped=1,temp;
    while(swapped!=0)
    {
    	swapped=0;
    	for(int i=0; i<n-1; i++)
    	{
    		if(values[i]>values[i+1])
    		{
    			temp=values[i];
    			values[i]=values[i+1];
    			values[i+1]=temp;
    			swapped=1;
    		}
    	}
    	n--;
    }
    return;
}
